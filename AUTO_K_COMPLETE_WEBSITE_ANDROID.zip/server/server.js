'use strict';
const express = require('express');
const crypto = require('node:crypto');
const path = require('node:path');
const app = express();
const PORT = process.env.PORT || 3000;
const OWNER_ID = process.env.OWNER_ID || 'ak070840';
// Scrypt format: base64url(salt):base64url(derived key). Never store the raw password here.
const OWNER_PASSWORD_SCRYPT = process.env.OWNER_PASSWORD_SCRYPT || 'lAiE0vHyBatf21A1N90elg:qHw3kZdnQ2-GRUY088UaLVVr7lpBNFl8-nAPR_HXL8gfxIEZWN2OKv6XEq4885VMgdljxT_4keBKY52hsxvniQ';
const SESSION_COOKIE = 'autok_session';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const sessions = new Map();
const attempts = new Map();
app.disable('x-powered-by');
app.use(express.json({limit:'20kb'}));
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','same-origin');
  res.setHeader('X-Frame-Options','DENY');
  next();
});
function parseCookies(req){ return Object.fromEntries((req.headers.cookie||'').split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i),decodeURIComponent(v.slice(i+1))]})); }
function checkPassword(candidate){
  try {
    const [saltB64,keyB64] = OWNER_PASSWORD_SCRYPT.split(':');
    const salt = Buffer.from(saltB64,'base64url');
    const expected = Buffer.from(keyB64,'base64url');
    const actual = crypto.scryptSync(String(candidate), salt, expected.length, {N:16384,r:8,p:1,maxmem:64*1024*1024});
    return expected.length===actual.length && crypto.timingSafeEqual(expected,actual);
  } catch { return false; }
}
function currentSession(req){
  const token = parseCookies(req)[SESSION_COOKIE];
  const item = token && sessions.get(token);
  if(!item) return null;
  if(item.expiresAt < Date.now()){ sessions.delete(token); return null; }
  item.expiresAt = Date.now() + SESSION_TTL_MS;
  return item;
}
function requireOwner(req,res,next){ const s=currentSession(req); if(!s) return res.status(401).json({ok:false,message:'กรุณาเข้าสู่ระบบเจ้าของแอป'}); req.owner=s; next(); }
app.post('/api/login',(req,res)=>{
  const ip=req.ip || req.socket.remoteAddress || 'unknown';
  const now=Date.now(); const record=attempts.get(ip) || {count:0,until:now+10*60*1000};
  if(record.until<now){record.count=0;record.until=now+10*60*1000;}
  if(record.count>=10) return res.status(429).json({ok:false,message:'ลองเข้าสู่ระบบหลายครั้งเกินไป กรุณารอ 10 นาที'});
  const {id,password}=req.body||{};
  const validId=typeof id==='string' && crypto.timingSafeEqual(Buffer.from(id.padEnd(64,' ').slice(0,64)),Buffer.from(OWNER_ID.padEnd(64,' ').slice(0,64)));
  const validPassword=typeof password==='string' && password.length<=200 && checkPassword(password);
  if(!validId || !validPassword){record.count++;attempts.set(ip,record);return res.status(401).json({ok:false,message:'ID หรือ Password ไม่ถูกต้อง'});}
  attempts.delete(ip);
  const token=crypto.randomBytes(32).toString('base64url');
  sessions.set(token,{role:'owner',id:OWNER_ID,expiresAt:Date.now()+SESSION_TTL_MS});
  res.setHeader('Set-Cookie',`${SESSION_COOKIE}=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${SESSION_TTL_MS/1000}`);
  res.json({ok:true,user:{id:OWNER_ID,role:'owner'}});
});
app.get('/api/me',(req,res)=>{const s=currentSession(req);res.json({authenticated:!!s,user:s?{id:s.id,role:s.role}:null});});
app.post('/api/logout',(req,res)=>{const token=parseCookies(req)[SESSION_COOKIE];if(token)sessions.delete(token);res.setHeader('Set-Cookie',`${SESSION_COOKIE}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`);res.json({ok:true});});
app.get('/api/owner/status',requireOwner,(req,res)=>res.json({ok:true,owner:req.owner.id,role:'owner',freeLifetime:true,dailyClipLimit:10}));
app.use(express.static(path.join(__dirname,'public'),{index:'index.html'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`AUTO K server listening on ${PORT}`));
